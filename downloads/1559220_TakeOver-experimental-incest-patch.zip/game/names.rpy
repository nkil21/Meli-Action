
label start_names:
    $ Landlady = "Mother";
    $ landlady = "mother";
    $ landlady1 = "mom";
    $ tenant = "son";
    $ roomie = "sis";
    $ Roomie = "Sis";
    $ roomie1 = "bro"; #b
    $ Roommate = "Sister";
    $ roommate = "sister";
    $ roommate1 = "brother";  #b
    $ household = "family";
    $ tenants = "childen"; #c
    $ Roommate1 = "Brother"; #b

    $ roommate5 = "sister";
    $ Roommate5 = "Sister";


    $ tenant1 = "daughter"; #d
    $ landlord = "father";
    jump institutions_control

label update_names:

    $ Landlady = "Mother";
    $ landlady = "mother";
    $ landlady1 = "mom";
    $ tenant = "son";
    $ roomie = "sis";
    $ Roomie = "Sis";
    $ roomie1 = "bro"; #b
    $ Roommate = "Sister";
    $ roommate = "sister";
    $ roommate1 = "brother";  #b
    $ household = "family";
    $ tenants = "childen"; #c
    $ Roommate1 = "Brother"; #b

    $ roommate5 = "sister";
    $ Roommate5 = "Sister";


    $ tenant1 = "daughter"; #d
    $ landlord = "father";
    jump house
